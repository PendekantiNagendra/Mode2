package com.batch2;

import org.springframework.stereotype.Service;

@Service
public interface CustomerService {
	public int getCust_idByLogin_id(int login_id);
}
