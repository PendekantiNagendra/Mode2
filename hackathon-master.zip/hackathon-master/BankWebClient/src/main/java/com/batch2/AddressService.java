package com.batch2;

import org.springframework.stereotype.Service;

@Service
public interface AddressService {

	 void save(Address address);
		

	 public int getCustId();
		
    
}
