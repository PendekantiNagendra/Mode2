package com.batch2;

import org.springframework.stereotype.Service;

@Service
public interface LoginRegisterService {

	String authentication(String username, String password);

	public int save(String username, String password);
	
	int approveLogin(String username, String password);
	
}
